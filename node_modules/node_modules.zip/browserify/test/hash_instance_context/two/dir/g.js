// FILE G TWO
module.exports = require('./h.js') + 1;
