var robot = require('./robot.js');
console.log(robot('beep'));