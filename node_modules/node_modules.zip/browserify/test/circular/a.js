exports.a = 1;
exports.b = require('./b');
exports.a = 5;
