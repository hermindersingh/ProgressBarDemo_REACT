try { var x = require('./x') } catch (err) {}
console.log(x)
