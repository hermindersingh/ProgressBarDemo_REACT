var beep = require('beep');
var boop = require('./boop.js');

t.equal(boop(beep), 560);
